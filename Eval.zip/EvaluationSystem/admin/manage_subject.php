<?php
include '../db_connect.php';
if(isset($_GET['id'])){
	$qry = $conn->query("SELECT * FROM subject_list where id={$_GET['id']}")->fetch_array();
	foreach($qry as $k => $v){
		$$k = $v;
	}
}
?>
<link rel="stylesheet" href="./css/manage_subject.css">
<div class="subMan">
	<div class="smf">ADD/EDIT SUBJECT</div>
<hr />
	<form action="" id="manage-subject">
		<div class="subform">
			<label for="subject" class="control-label">Subject Code:</label>
			<br>
			<input type="text" class="form-control form-control-sm" name="code" id="code" value="<?php echo isset($code) ? $code : '' ?>" required>
		</div>
		<div class="subform">
		<label for="subject" class="control-label">Subject:</label>
		<br>
			<input type="text" class="form-control form-control-sm" name="subject" id="subject" value="<?php echo isset($subject) ? $subject : '' ?>" required>
		</div>
		<div class="subform">
			<label for="description" class="control-label">Description:</label>
			<br>
			<textarea name="description" id="description" cols="30" rows="4" class="form-control" required><?php echo isset($description) ? $description : '' ?></textarea>
		</div>
	</form>
	
</div>
<script>
$(document).ready(function(){
		$('#manage-subject').submit(function(e){
			location.replace('index.php?page=subject_list')
			e.preventDefault();
			start_load()
			$('#msg').html('')
			$.ajax({
				url:'ajax.php?action=save_subject',
				method:'POST',
				data:$(this).serialize(),
				success:function(resp){
					if(resp == 1){
						alert_toast("Data successfully saved.","success");
						setTimeout(function(){
							location.reload()	
						},1750)
					}else if(resp == 2){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Subject Code already exist.</div>')
						end_load()
					}
				}
			})
		})
	})

</script>