	
	<link rel="stylesheet" href="./css/sidebar.css">


	 <div class="sidebar">
	<nav class="m.2">
		<div class="text">Admin</div>
		<ul>
			<li><a href="./" >Dashboard</a></li>
			<li>
				<a href="./index.php?page=subject_list">Subjects</a>
			</li>
			<li>
				<a href="./index.php?page=class_list">Classes</a>
			</li>
			<li>
				<a href="./index.php?page=academic_list">Academic Year</a>
			</li> 
			<li>
				<a href="./index.php?page=questionnaire">Questionnaires</a>
			</li>
			<li class="nav-item dropdown">
				<a href="./index.php?page=criteria_list" >Criteria</a>
			</li>
			<li>
				<a href="#" class="stud-btn">Students
					<span class="fas fa-caret-down first"></span>
				</a>
				<ul class="stud-show">
					<li><a href="./index.php?page=new_student">Add Student</a></li>
					<li><a href="./index.php?page=student_list">List</a></li>

				</ul>	
			</li>
			<li>
				<a href="#" class="fac-btn">Faculties
					<span class="fas fa-caret-down second"></span>
				</a>
				<ul class="fac-show">
					<li><a href="./index.php?page=new_faculty">Add Faculty</a></li>
					<li><a href="./index.php?page=faculty_list">List</a></li>

				</ul>	
			</li>
			
			<li>
				<a href="#" class="adm-btn">Admins
					<span class="fas fa-caret-down third"></span>
				</a>
				<ul class="adm-show">
					<li><a href="./index.php?page=new_user">Add</a></li>
					<li><a href="./index.php?page=user_list">List</a></li>
				</ul>	
			</li>
			<li>
				<a href="./index.php?page=report">Evaluation Reports</a>
			</li>

			<li>
				<a href="./index.php?page=archived">Archived</a>
			</li>
		</ul>

	</nav>
</div>

	<script>


		$('.stud-btn').click(function(){
			$('nav ul .stud-show').toggleClass("show");
			$('nav ul .first').toggleClass("rotate");
		});
		$('.fac-btn').click(function(){
			$('nav ul .fac-show').toggleClass("show1");
			$('nav ul .second').toggleClass("rotate");
		});
		$('.adm-btn').click(function(){
			$('nav ul .adm-show').toggleClass("show2");
			$('nav ul .third').toggleClass("rotate");
		});



	</script>
